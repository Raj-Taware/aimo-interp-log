"""Per-model last-token linear probes for the four Small Models Track IDs.

Mirrors the trained-probe baseline contract (final prompt-token @ selected
layer → conservative high-confidence gate ⇒ robust; legacy mean-margin≥0 available via CONSERVATIVE=False) but is cascade-aware: missing
artifact or no GPU/local model ⇒ ``None`` (skip), never a raised exception
that would invalidate the batch.

Public val-sample labels are treated as noisy proxies of hidden H — not as a
reconstruction target. Artifacts should be trained offline per Competition
model id (verbatim HF id).
"""

from __future__ import annotations

import pickle
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

SMALL_TRACK_MODEL_IDS: frozenset[str] = frozenset(
    {
        "Qwen/Qwen3.5-4B",
        "Skywork/Skywork-OR1-Math-7B",
        "allenai/Olmo-3-7B-Think",
        "deepseek-ai/DeepSeek-R1-0528-Qwen3-8B",
    }
)

RECOMMENDED_STRATEGY = "best_layer_mean_margin"

# Conservative True gate (Codabench 949901 over-predicted True → 0.4286).
# Prefer False unless mean margin clears a raised bar AND most seed margins agree.
CONSERVATIVE = True
TRUE_MARGIN_THRESHOLD = 0.5  # was implicit 0.0 (mean margin >= 0)
MIN_POSITIVE_MARGIN_FRAC = 0.75  # fraction of seed margins that must be >= 0


@dataclass(frozen=True)
class ProbeArtifactRef:
    path: Path
    model_id: str


@dataclass(frozen=True)
class ProbeArtifact:
    """Loaded schema-v2 ensemble pickle (same contract as trained-probe)."""

    model_id: str
    system_prompt: str
    data: dict[str, Any]
    path: Path


def _safe_model_id(model_id: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", model_id).strip("_")


def artifact_candidates(model_id: str, root: Path | None = None) -> list[Path]:
    base = root or Path(__file__).resolve().parent
    artifacts = base / "artifacts"
    safe = _safe_model_id(model_id)
    names: list[Path] = []
    if safe:
        names.extend(
            [
                artifacts / f"probe_{safe}.pkl",
                artifacts / f"{safe}.pkl",
            ]
        )
    names.append(artifacts / "probe_artifact.pkl")
    return names


def find_probe_artifact(model_id: str, root: Path | None = None) -> ProbeArtifactRef | None:
    for path in artifact_candidates(model_id, root=root):
        if path.is_file():
            return ProbeArtifactRef(path=path, model_id=model_id)
    return None


def load_pickle_artifact(path: Path) -> ProbeArtifact:
    """Load and validate a schema-v2 probe-ensemble pickle.

    Raises ``RuntimeError`` on schema mismatch so callers can skip the stage.
    """
    with path.open("rb") as handle:
        data = pickle.load(handle)

    if not isinstance(data, dict):
        raise RuntimeError(f"{path.name} must contain a dictionary artifact")
    if data.get("schema_version") != 2:
        raise RuntimeError(
            f"{path.name} has unsupported schema_version {data.get('schema_version')!r}"
        )
    if data.get("artifact_type") != "all_folds_layers_seed_probe_ensemble":
        raise RuntimeError(
            f"{path.name} has unsupported artifact_type {data.get('artifact_type')!r}"
        )
    if not data.get("groups"):
        raise RuntimeError(f"{path.name} contains no probe groups")
    if "best_layer_index" not in data:
        raise RuntimeError(f"{path.name} is missing best_layer_index")

    strategy = data.get("recommended_strategy") or {}
    if strategy and strategy.get("name") != RECOMMENDED_STRATEGY:
        raise RuntimeError(
            f"{path.name} recommends unsupported strategy {strategy.get('name')!r}"
        )

    return ProbeArtifact(
        model_id=str(data.get("model_id") or ""),
        system_prompt=str(data.get("system_prompt") or ""),
        data=data,
        path=path,
    )


def load_probe_for_model(model_id: str, root: Path | None = None) -> ProbeArtifact | None:
    """Find and load the matching per-model artifact, or ``None`` if absent/bad."""
    ref = find_probe_artifact(model_id, root=root)
    if ref is None:
        return None
    try:
        return load_pickle_artifact(ref.path)
    except Exception:
        return None


def gpu_ready() -> bool:
    try:
        import torch

        return bool(torch.cuda.is_available())
    except Exception:
        return False


def _layer_index(artifact: ProbeArtifact) -> int:
    strategy = artifact.data.get("recommended_strategy") or {}
    return int(strategy.get("layer_index", artifact.data["best_layer_index"]))


def ensemble_margins(vector: Any, artifact: ProbeArtifact) -> list[float]:
    """Signed margins for every seed/fold probe at the selected layer."""
    import numpy as np

    layer_index = _layer_index(artifact)
    margins: list[float] = []
    for group in artifact.data["groups"]:
        probes = group.get("probes", {})
        probe = probes.get(layer_index, probes.get(str(layer_index)))
        if probe is None:
            continue

        weights = np.asarray(probe["weights"], dtype=np.float32)
        if weights.ndim == 1:
            weights = weights.reshape(1, -1)
        if weights.ndim != 2 or weights.shape[1] != vector.shape[0]:
            raise RuntimeError(
                f"probe dimension mismatch: got {vector.shape[0]}, expected {weights.shape[-1]}"
            )

        bias = np.asarray(probe["bias"], dtype=np.float32).reshape(-1)
        threshold = np.asarray(probe["threshold"], dtype=np.float32).reshape(-1)
        if bias.size != weights.shape[0] or threshold.size != weights.shape[0]:
            raise RuntimeError("probe ensemble arrays have inconsistent seed dimensions")

        margins.extend((weights @ vector + bias - threshold).astype(float).tolist())

    if not margins:
        raise RuntimeError(f"artifact contains no probes for layer {layer_index}")
    return margins


def mean_ensemble_margin(vector: Any, artifact: ProbeArtifact) -> float:
    """Average signed margin across every probe in the ensemble (trained-probe)."""
    import numpy as np

    margins = ensemble_margins(vector, artifact)
    return float(np.mean(np.asarray(margins, dtype=np.float64)))


def decide_robust_from_margins(
    margins: Sequence[float],
    *,
    conservative: bool = CONSERVATIVE,
    margin_threshold: float = TRUE_MARGIN_THRESHOLD,
    min_positive_frac: float = MIN_POSITIVE_MARGIN_FRAC,
) -> bool:
    """Map seed margins → native bool. Conservative mode prefers False.

    Legacy path (``conservative=False``): True iff mean(margin) >= 0.
    Conservative path: True only if mean(margin) >= ``margin_threshold`` AND
    at least ``min_positive_frac`` of individual seed margins are >= 0.
    Empty margins → False (never invent True).
    """
    if not margins:
        return False
    import numpy as np

    arr = np.asarray(list(margins), dtype=np.float64)
    mean_m = float(np.mean(arr))
    if not conservative:
        return bool(mean_m >= 0.0)
    pos_frac = float(np.mean(arr >= 0.0))
    return bool(mean_m >= margin_threshold and pos_frac >= min_positive_frac)


def _load_hf_model(model_id: str) -> tuple[Any, Any]:
    """Load tokenizer + causal LM from the offline HF cache only (no download)."""
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    device = "cuda" if torch.cuda.is_available() else "cpu"
    if device == "cuda":
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    else:
        dtype = torch.float32

    tokenizer = AutoTokenizer.from_pretrained(model_id, local_files_only=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        dtype=dtype,
        local_files_only=True,
    )
    model.to(device)
    model.eval()
    return tokenizer, model


def _build_prompt(tokenizer: Any, problem_text: str, system_prompt: str) -> str:
    if system_prompt and hasattr(tokenizer, "apply_chat_template"):
        try:
            return tokenizer.apply_chat_template(
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": problem_text},
                ],
                tokenize=False,
                add_generation_prompt=True,
            )
        except Exception:
            pass
    return f"{system_prompt}\n\n{problem_text}" if system_prompt else problem_text


def _encode_problem(problem_text: str, artifact: ProbeArtifact, tokenizer: Any, model: Any) -> Any:
    """Last prompt-token hidden state at the probe layer (float32 numpy)."""
    import torch

    prompt = _build_prompt(tokenizer, problem_text, artifact.system_prompt)
    model_inputs = tokenizer(prompt, return_tensors="pt", truncation=True)
    model_inputs = {name: value.to(model.device) for name, value in model_inputs.items()}

    with torch.no_grad():
        output = model(
            **model_inputs,
            output_hidden_states=True,
            return_dict=True,
            use_cache=False,
        )

    hidden_states = output.hidden_states
    if hidden_states is None:
        raise RuntimeError("model forward pass returned no hidden states")

    layer_index = _layer_index(artifact)
    if not -len(hidden_states) <= layer_index < len(hidden_states):
        raise RuntimeError(
            f"probe layer {layer_index} is outside model hidden-state range "
            f"0..{len(hidden_states) - 1}"
        )
    return hidden_states[layer_index][0, -1, :].detach().float().cpu().numpy()


def _predict_with_gpu(artifact: ProbeArtifact, problems: Sequence[str]) -> list[bool]:
    """Run HF encode + mean-ensemble margin on CUDA. Raises on any failure."""
    import numpy as np

    # Prefer the artifact's recorded HF id (training id) over the caller's alias.
    hf_id = str(artifact.data.get("hf_model_id") or artifact.model_id or "")
    if not hf_id:
        raise RuntimeError("artifact missing model_id / hf_model_id")

    tokenizer, model = _load_hf_model(hf_id)
    out: list[bool] = []
    for problem_text in problems:
        vector = np.asarray(
            _encode_problem(problem_text, artifact, tokenizer, model),
            dtype=np.float32,
        )
        margins = ensemble_margins(vector, artifact)
        out.append(decide_robust_from_margins(margins))
    return out


def last_token_probe_votes(
    model_id: str,
    problems: Sequence[str],
) -> list[bool] | None:
    """Score last-token probes or return ``None`` to skip this cascade stage.

    On CPU / without a matching per-model artifact / without a local HF cache,
    returns ``None`` so the cascade falls through without invalidating coverage.
    Never invents GPU predictions on a CPU box.
    """
    if not problems:
        return []

    artifact = load_probe_for_model(model_id)
    if artifact is None:
        return None
    if not gpu_ready():
        return None

    try:
        return _predict_with_gpu(artifact, problems)
    except Exception:
        # Missing local weights, OOM, schema mismatch at score time, etc.
        return None


def describe_expected_artifact() -> dict[str, Any]:
    """Document expected on-disk schema for GPU training/export."""
    return {
        "schema_version": 2,
        "artifact_type": "all_folds_layers_seed_probe_ensemble",
        "recommended_strategy": "best_layer_mean_margin",
        "keys": [
            "model_id",
            "system_prompt",
            "best_layer_index",
            "groups[*].probes[layer].{weights,bias,threshold}",
        ],
        "small_track_model_ids": sorted(SMALL_TRACK_MODEL_IDS),
    }
