# Hybrid Cascade (budget-aware Small Models Track)

Method taste: **short early-trace uncertainty + cheap K=1–2 counterfactuals +
per-model last-token probes**, fused under a **cascade abort &lt; 3600s**.
Public `model_is_robust` / val-sample labels are **proxies**, not a
reconstruction of the unpublished private labelling rule H.

## Layout

```text
hybrid-cascade/
├── solution.py              # are_robust(model_id, reasoning_effort, problems)
├── cascade.py               # order, wall budget, all-False fallback
├── uncertainty_features.py  # short early-trace stage (GPU)
├── counterfactual.py        # K=1–2 light transforms (GPU)
├── probe_infer.py           # per-model last-token probes (GPU)
├── artifacts/               # per-model probe_*.pkl (3 Small IDs shipped; DeepSeek TBD)
└── README.md
```

Small-track packaging: build with `uv run scripts/build.py solutions --small`
so the ZIP root contains blank `small.txt`
→ `dist/solution-hybrid-cascade-small.zip`.

## Cascade order

| Step | Module | What it does | Needs GPU? | Needs local HF weights? | Needs bundled artifact? |
|---:|---|---|---|---|---|
| 1 | `uncertainty_features` | Greedy short gen (≪4096 tokens), early-trace aggregates → soft score | **Yes** | **Yes** | Optional short-trace `.joblib` per model |
| 2 | `counterfactual` | Original + K=1–2 light offline transforms; answer agreement ⇒ robust | **Yes** | **Yes** | No (behavioural) |
| 3 | `probe_infer` | Last prompt-token @ selected layer; **conservative** True only if mean margin ≥ 0.5 **and** ≥75% seed margins ≥ 0 | **Yes** | **Yes** | **Yes** — one probe pack per Small ID |
| 4 | fallback | Deterministic `False` × N | No | No | No |

- If a stage returns `None` (no CUDA, no artifact, no cache) or raises, the
  cascade **skips** to the next stage.
- If wall time exceeds ~80% of **3600s**, remaining expensive stages are
  aborted and the fallback is used so coverage stays 1.0 / invalid=0.
- Predictions are always **native Python `bool`**, same length/order as
  `problems`.

## Small Models Track IDs (verbatim)

Artifacts and checkpoints must key on these exact HF ids (Competition does
**not** pass `:low` aliases):

- `Qwen/Qwen3.5-4B`
- `Skywork/Skywork-OR1-Math-7B`
- `allenai/Olmo-3-7B-Think`
- `deepseek-ai/DeepSeek-R1-0528-Qwen3-8B`

Suggested on-disk names under `artifacts/`:

- `probe_<safe-model-id>.pkl` (schema-v2 ensemble, `best_layer_mean_margin`)
- `uncertainty_<safe-model-id>.joblib` (short-trace regressor + threshold)

`<safe-model-id>` replaces `/`, `:`, and whitespace with `_`.

## CPU box behaviour (this workspace)

No GPU (`torch.cuda.is_available() == False`) and no large HF downloads by
policy ⇒ every GPU stage returns `None` ⇒ **all-False** baseline. That is a
**valid** Codabench contract smoke (coverage=1, invalid=0), not a claim about
private-test accuracy.

## GPU next steps (do these on a CUDA box / Codabench image)

1. **Do not download weights on the CPU laptop** — use the eval image cache or
   an offline mirror.
2. Train / export **four** last-token probe packs (one per Small id); copy into
   `artifacts/probe_*.pkl`.
3. Fit short-trace uncertainty regressors with hard `max_new_tokens` (e.g. 64–
   256), problem-grouped CV; map decay/proxy → bool; ship `uncertainty_*.joblib`.
4. Wire the GPU bodies in `short_trace_scores`, `counterfactual_stability_votes`,
   and `last_token_probe_votes` (currently stubs that return `None` without
   CUDA).
5. Time a Dummy Full Run of all models × problems; keep p95 ≪ 0.8 × 3600s;
   tune K and token caps before freeze.
6. Treat public labels as noisy proxies; prefer stability / decay targets with
   grouped-by-problem validation — do not chase secret H thresholds.


## Conservative mode (post–Codabench 949901)

After official Small-track accuracy **0.4286** (probes over-predicted True vs
all-False majority), defaults prefer False:

| Flag | Where | Effect |
|---|---|---|
| `CONSERVATIVE=True` | `probe_infer.py` | True only if mean margin ≥ `TRUE_MARGIN_THRESHOLD` (0.5) and ≥ `MIN_POSITIVE_MARGIN_FRAC` (0.75) of seed margins ≥ 0 |
| `CONSERVATIVE_MODE=True` | `cascade.py` | Skip any stage whose True rate > `MAX_STAGE_TRUE_RATE` (0.35) → fall through to all-False |
| uncertainty threshold 0.70 | `cascade.py` | When short-trace stage is wired, raise soft-score bar |

No CUDA / missing artifact / missing local weights still → all-False (coverage-safe).
`are_robust(model_id, reasoning_effort, problems) -> list[bool]` unchanged.

## Local validate & package

```bash
uv run scripts/build.py solutions --small
uv run scripts/run_local.py dist/solution-hybrid-cascade-small.zip --small \
  --input-dir data/val-sample/input \
  --reference-dir data/val-sample/reference
```

Expect on CPU: coverage `1.0`, invalid_predictions `0`, accuracy equal to the
all-False base rate on the local label mix (report the measured JSON only).
