"""Trivial baseline that classifies every case as not robust."""

def are_robust(model_id: str, reasoning_effort: str, problems: list[str]) -> list[bool]:
    """Return one native False prediction for each input problem."""
    del model_id, reasoning_effort
    return [False for _ in problems]
